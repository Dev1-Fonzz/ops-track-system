"use client";

import { useEffect, useState } from "react";
import { db, auth } from "../../../lib/firebase";
import { ref, set } from "firebase/database";
import { signInAnonymously } from "firebase/auth";

const MISSION_ID = "MISI-001";
const DEST_LAT = 3.1579; // KLCC
const DEST_LNG = 101.7116;
const RADIUS_TIBA = 100; // Meter

export default function DriverPage() {
  const [status, setStatus] = useState("Menunggu GPS...");
  const [distance, setDistance] = useState(0);
  const [isArrived, setIsArrived] = useState(false);

  useEffect(() => {
    const initTracking = async () => {
      try {
        await signInAnonymously(auth);
        console.log("Driver logged in");
      } catch (error) {
        console.error("Login error", error);
      }

      if (!navigator.geolocation) {
        setStatus("GPS tidak disokong!");
        return;
      }

      navigator.geolocation.watchPosition(
        async (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          
          // Kira Jarak (Haversine)
          const R = 6371e3; 
          const φ1 = (lat * Math.PI) / 180;
          const φ2 = (DEST_LAT * Math.PI) / 180;
          const Δφ = ((DEST_LAT - lat) * Math.PI) / 180;
          const Δλ = ((DEST_LNG - lng) * Math.PI) / 180;
          const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
                    Math.cos(φ1) * Math.cos(φ2) *
                    Math.sin(Δλ/2) * Math.sin(Δλ/2);
          const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
          const dist = R * c;

          setDistance(Math.round(dist));
          let currentStatus = "in_transit";
          let arrivedTime = null;

          if (dist <= RADIUS_TIBA) {
            currentStatus = "arrived";
            setIsArrived(true);
            setStatus("✅ TELAH SAMPAI DI DESTINASI");
            arrivedTime = new Date().toISOString();
            if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
          } else {
            setIsArrived(false);
            setStatus(`🚛 Dalam Perjalanan (${Math.round(dist)}m lagi)`);
          }

          // Update Firebase
          const updates = {
            [`missions/${MISSION_ID}/tracking/currentLat`]: lat,
            [`missions/${MISSION_ID}/tracking/currentLng`]: lng,
            [`missions/${MISSION_ID}/tracking/lastUpdated`]: Date.now(),
            [`missions/${MISSION_ID}/status/current`]: currentStatus,
            [`missions/${MISSION_ID}/status/distanceRemaining`]: Math.round(dist),
          };
          if (arrivedTime) {
            updates[`missions/${MISSION_ID}/status/arrivedAt`] = arrivedTime;
          }

          await set(ref(db, `missions/${MISSION_ID}`), updates);
        },
        (err) => setStatus("Ralat GPS: " + err.message),
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    };

    initTracking();
  }, []);

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center p-6 text-white transition-colors duration-500 ${isArrived ? 'bg-green-600' : 'bg-blue-600'}`}>
      <h1 className="text-2xl font-bold mb-6">PANEL PEMANDU</h1>
      
      <div className="bg-white/20 backdrop-blur-md p-6 rounded-xl w-full max-w-sm text-center shadow-lg">
        <p className="text-sm uppercase tracking-wide opacity-80">Status Semasa</p>
        <h2 className="text-2xl font-black my-4">{status}</h2>
        
        <div className="grid grid-cols-2 gap-4 mt-6">
          <div className="bg-black/30 p-3 rounded-lg">
            <span className="block text-xs opacity-70">Jarak Lagi</span>
            <span className="text-xl font-mono font-bold">{distance} m</span>
          </div>
          <div className="bg-black/30 p-3 rounded-lg">            <span className="block text-xs opacity-70">Destinasi</span>
            <span className="text-sm font-bold">KLCC</span>
          </div>
        </div>

        {isArrived && (
          <div className="mt-6 bg-green-800 border border-green-400 p-3 rounded animate-pulse">
            <p className="font-bold text-sm">Lokasi dihantar ke Operator!</p>
          </div>
        )}
      </div>
      <p className="mt-8 text-xs opacity-60">Biarkan skrin hidup untuk tracking live.</p>
    </div>
  );
}