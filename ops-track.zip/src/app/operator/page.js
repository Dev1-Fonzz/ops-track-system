"use client";

import { useEffect, useState } from "react";
import { db } from "../../../lib/firebase";
import { ref, onValue } from "firebase/database";
import dynamic from 'next/dynamic';

// Import dinamik untuk Leaflet (Elak error server)
const MapContainer = dynamic(() => import('react-leaflet').then(m => m.MapContainer), { ssr: false });
const TileLayer = dynamic(() => import('react-leaflet').then(m => m.TileLayer), { ssr: false });
const Marker = dynamic(() => import('react-leaflet').then(m => m.Marker), { ssr: false });
const Popup = dynamic(() => import('react-leaflet').then(m => m.Popup), { ssr: false });

export default function OperatorPage() {
  const [data, setData] = useState(null);
  
  useEffect(() => {
    const missionRef = ref(db, 'missions/MISI-001');
    const unsubscribe = onValue(missionRef, (snapshot) => {
      const val = snapshot.val();
      if (val) setData(val);
    });
    return () => unsubscribe();
  }, []);
  
  if (!data) return <div className="p-10 text-center text-gray-500">Menunggu data live dari driver...</div>;
  
  const isArrived = data.status?.current === 'arrived';
  const lat = data.tracking?.currentLat;
  const lng = data.tracking?.currentLng;
  const destLat = data.destination?.targetLat;
  const destLng = data.destination?.targetLng;
  
  return (
    <div className="min-h-screen bg-gray-900 text-white pb-10">
      {/* Header */}
      <div className="bg-gray-800 p-4 shadow-md sticky top-0 z-50">
        <h1 className="text-xl font-bold text-center">🚨 DASHBOARD OPERATOR</h1>
      </div>

      <div className="p-4 max-w-2xl mx-auto">
        {/* Kad Status Utama */}
        <div className={`p-6 rounded-xl mb-4 text-center border-4 shadow-lg transition-all ${isArrived ? 'bg-green-900 border-green-500' : 'bg-blue-900 border-blue-500'}`}>
          <h2 className="text-2xl font-bold">{data.info?.driverName || "Unknown Driver"}</h2>
          <p className="opacity-70">{data.info?.vehiclePlate}</p>
          
          <div className="my-4 text-3xl font-black">
            {isArrived ? '✅ TELAH SAMPAI' : '🚛 SEDANG BERGERAK'}
          </div>
                    <div className="bg-black/40 inline-block px-4 py-2 rounded-lg">
            <span className="text-sm opacity-70">Baki Jarak:</span> 
            <span className="ml-2 text-xl font-mono">{data.status?.distanceRemaining || '?'} meter</span>
          </div>
        </div>

        {/* Maklumat Lanjut */}
        <div className="bg-gray-800 p-4 rounded-xl mb-4 space-y-2 text-sm">
          <div className="flex justify-between border-b border-gray-700 pb-2">
            <span className="opacity-60">Kargo:</span>
            <span className="font-semibold">{data.info?.cargoType}</span>
          </div>
          <div className="flex justify-between border-b border-gray-700 pb-2">
            <span className="opacity-60">Contact:</span>
            <span className="font-semibold">{data.info?.contactNumber}</span>
          </div>
          <div className="flex justify-between">
            <span className="opacity-60">Nota:</span>
            <span className="font-semibold italic">{data.info?.notes}</span>
          </div>
          {data.status?.arrivedAt && (
             <div className="mt-4 pt-4 border-t border-gray-700 text-green-400 font-bold text-center">
               MASA TIBA: {new Date(data.status.arrivedAt).toLocaleTimeString()}
             </div>
          )}
        </div>

        {/* Peta Live */}
        <div className="h-64 w-full rounded-xl overflow-hidden border-2 border-gray-700 shadow-lg relative z-0">
          {lat && lng ? (
            <MapContainer center={[lat, lng]} zoom={15} style={{ height: '100%', width: '100%' }} scrollWheelZoom={false}>
              <TileLayer
                attribution='&copy; OpenStreetMap'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              {/* Marker Driver */}
              <Marker position={[lat, lng]}>
                <Popup>📍 Lokasi Driver Live</Popup>
              </Marker>
              {/* Marker Destinasi */}
              {destLat && (
                <Marker position={[destLat, destLng]}>
                  <Popup>🏁 Destinasi</Popup>
                </Marker>
              )}
            </MapContainer>
          ) : (
            <div className="flex items-center justify-center h-full bg-gray-800 text-gray-400">
              Menunggu koordinat pertama...
            </div>          )}
        </div>
      </div>
    </div>
  );
}